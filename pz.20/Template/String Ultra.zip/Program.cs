﻿namespace $safeprojectname$
{
    internal class Program
    {
        void stringULTRA(ref string data)
        {
            for (int i = 0; i < data.Length; i++) 
            {
                // Paste your code here;
            }
        }

        static void Main(string[] args)
        {
            // stringULTRA(ref PASTE_YOUR_STRING_HERE);             -Uncomment this
        }
    }
}